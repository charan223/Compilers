#include "myl.h"
int main()
{
	//Testing printi
	prints("Testing of print integer");
	prints("\n");
	printi(987);
	prints("\n");
	printi(-123);
	prints("\n");

	//Testing prints
	prints("Testing of print string");
	prints("\n");

	//Testing printd
	prints("Testing of print float");
	prints("\n");
	printd(123.456);
	prints("\n");
	printd(-123.456);

	prints("\n");

	//Testing readi
	int n;
	prints("Testing of read integer");
	int k=readi(&n);
	printi(k);
    prints("\n");

	//Testing readf
	float fp;
	prints("Testing of read float");
	readf(&fp);
	printd(fp);
return 0;
}
