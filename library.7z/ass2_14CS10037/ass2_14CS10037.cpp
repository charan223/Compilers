#include "myl.h"
#define BUFF 11
#define BUFF1 40

//PRINTS STRING
int prints(const char * input)
{
    char *buffer;
    int strlength=0;
    if(input==0)
        return 0;
    for(strlength=0; input[strlength]!=0; strlength++);
    buffer= new char[strlength];
    for(int i=0; i<strlength; i++)
    {
        buffer[i]= input[i];
    }

    __asm__ __volatile__ (
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        :"S"(buffer), "d"(strlength)
    ) ;
    //freeing space
    delete [] buffer;

    //returning no of characters printed
    return strlength;
}
/*
prints a string of characters. The parameter
is terminated by '\0'. The return value is the number of characters
printed.
*/

//PRINTS INT
int printi(int n)
{

    char buffer[BUFF], zero='0',temp;
    int i=0, j, k, sizeofbuff,dig;
    if(n == 0)
        buffer[i++]=zero;
    else
    {
        if(n < 0)
        {
            buffer[i++]='-';
            n = -n;
        }
        while(n)
        {
            dig = n%10;
            buffer[i++] = (char)(zero+dig);
            n /= 10;
        }
        if(buffer[0] == '-')
            j = 1;
        else j = 0;
        k=i-1;
        while(j<k)
        {
            temp=buffer[j];
            buffer[j++] = buffer[k];
            buffer[k--] = temp;
        }
    }
    buffer[i]='\0';
    sizeofbuff = i;
//printf("%s\n",buff);
//printf("%d\n",bytes);
    __asm__ __volatile__ (
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        :"S"(buffer), "d"(sizeofbuff)
    ) ; // $4: write, $1: on stdin
    return sizeofbuff;
}


/*
prints the integer value of n (no newline). It
returns the number of characters printed.
*/


//READS INT
int readi(int *ep)
{
    char buffer[BUFF];
    int i,sizeofbuff,k, result=0;
    __asm__ __volatile__(
        "movl $0, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :"=rax"(sizeofbuff)
        :"S"(buffer),"d"(11)
    );

    sizeofbuff--;
    if (sizeofbuff <=0)
    {
        *ep = ERR;

        return 0;
    }
    if (buffer[0]=='-')                       // Checking whether the number is negtive or not
    {
        i=1;
    }
    else
    {
        i=0;
    }
    k=sizeofbuff;
    while(i<k)
    {
        if (buffer[i]>='0' && buffer[i]<='9')
        {
            result = result*10 + (buffer[i]-'0');     //Calculating the result
            i++;
        }
        else if(buffer[i] == '\n' || buffer[i] == '.')
        {
            break;
        }
        else
        {
            *ep = ERR;        //ERR
            return 0;
        }
    }
    if (buffer[0]=='-')
    {
        result = -1*result;
    }
    *ep = OK;          //OK

    //returning integer(signed)
    return result;
}
/*
reads an integer (signed) and returns it. The
parameter is for error (ERR = 1, OK = 0).
*/

//READS FLOAT
int readf(float *fp)
{
    char buffer[BUFF1];
    int i,sizeofbuff,k;
    int countchecker;

    __asm__ __volatile__(
        "movl $0, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :"=rax"(sizeofbuff)
        :"S"(buffer),"d"(40)
    );
    float x;
    int j=0;
    while(buffer[j]!= '.' && buffer[j]!='\n')
    {
        j++;
    }
    sizeofbuff--;
    if (sizeofbuff <=0)
    {
        countchecker = ERR;
        return 0;
    }
    if (buffer[0]=='-')                       // Checking whether the number is negtive or not
    {
        i=1;
    }
    else
    {
        i=0;
    }
    k=j;
    *fp = 0;
    while(i<k)
    {
        if (buffer[i]>='0' && buffer[i]<='9')
        {
            *fp = (*fp)*10 + (buffer[i]-'0');     //Calculating the result
            i++;
        }
        else if(buffer[i] == '\n')
        {
            break;
        }
        else
        {
            countchecker = ERR;        //ERR
            return 0;
        }
    }

    if(buffer[j] != '.')
    {
        if(buffer[0] == '-')
            *fp = -1*(*fp);
        return 0;
    }

    float l=0.1;
    int g=1;
    while(buffer[j+g] != '\n')
    {
        (*fp)+=(int)(buffer[j+g]-'0')* (l);
        l=l*0.1;
        g++;
    }

    if (buffer[0]=='-')
    {
        *fp = -1*(*fp);
    }
    countchecker = OK;          //OK



//returning whether it is ERR or OK...returns 0 if OK 1 if ERR
    return countchecker;
}
/*
reads a floating point number in ¡¯%f¡¯ format
e.g. -123.456. Caller get the value through the pointer parameter.
The return value is ERR or OK.
*/

//PRINTS FLOAT
int printd(float f)
{
    char buffer[BUFF1];
    char zero='0';
    char checks;
    int k=(int)f;
    float w=f-k*1.0;
    if(w<0)
        w= -w;
    int i=0, j, k1, floatcount,dig,h;
    if(k == 0) buffer[i++]=zero;
    else
    {
        if(k < 0)
        {
            buffer[i++]='-';
            k = -k;
        }
        while(k)
        {
            dig = k%10;
            buffer[i++] = (char)(zero+dig);
            k /= 10;
        }
        if(buffer[0] == '-') j = 1;
        else j = 0;
        k1=i-1;
        while(j<k1)
        {
            checks=buffer[j];
            buffer[j++] = buffer[k1];
            buffer[k1--] = checks;
        }
    }

    if(w!=0) buffer[i++]='.';
    int count =0;
    while(w!=0&&count<6)
    {
        h=(int)(w*10);
        buffer[i++]=(char)(zero+h);
        w=w*10-h*1.0;
        count++;
    }

    floatcount = i;
    __asm__ __volatile__ (
        "movl $1, %%eax \n\t"
        "movq $1, %%rdi \n\t"
        "syscall \n\t"
        :
        :"S"(buffer), "d"(floatcount)
    ) ;


//Returning number of characters printed
    return floatcount;
}


/*
prints the floating point number passed as
parameter. Returns the number of characters printed.
*/
