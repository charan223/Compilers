/* A Bison parser, made by GNU Bison 3.0.2.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2013 Free Software Foundation, Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    INT_NUMBER = 258,
    FLOAT_NUMBER = 259,
    CHARACTER = 260,
    IDENTIFIER = 261,
    STRING_LITERAL = 262,
    KEYWOD_AUTO = 263,
    KEYWOD_BREAK = 264,
    KEYWOD_CASE = 265,
    KEYWOD_CHAR = 266,
    KEYWOD_CONST = 267,
    KEYWOD_CONTINUE = 268,
    KEYWOD_DEFAULT = 269,
    KEYWOD_DO = 270,
    KEYWOD_DOUBLE = 271,
    KEYWOD_ELSE = 272,
    KEYWOD_ENUM = 273,
    KEYWOD_EXTERN = 274,
    KEYWOD_FLOAT = 275,
    KEYWOD_FOR = 276,
    KEYWOD_GOTO = 277,
    KEYWOD_IF = 278,
    KEYWOD_INLINE = 279,
    KEYWOD_INT = 280,
    KEYWOD_LONG = 281,
    KEYWOD_REGISTER = 282,
    KEYWOD_RESTRICT = 283,
    KEYWOD_RETURN = 284,
    KEYWOD_SHORT = 285,
    KEYWOD_SIGNED = 286,
    KEYWOD_SIZEOF = 287,
    KEYWOD_STATIC = 288,
    KEYWOD_STRUCT = 289,
    KEYWOD_SWITCH = 290,
    KEYWOD_TYPEDEF = 291,
    KEYWOD_UNION = 292,
    KEYWOD_UNSIGNED = 293,
    KEYWOD_VOID = 294,
    KEYWOD_VOLATILE = 295,
    KEYWOD_WHILE = 296,
    KEYWOD_BOOL = 297,
    KEYWOD_COMPLEX = 298,
    KEYWOD_IMAGINARY = 299,
    LEF_SQUARE_BRACKET = 300,
    RIGH_SQUARE_BRACKET = 301,
    LEF_PARANTHESIS = 302,
    RIGH_PARANTHESIS = 303,
    LEF_CURLY_BRACKET = 304,
    RIGH_CURLY_BRACKET = 305,
    DOT = 306,
    RIGH_ARROW = 307,
    UNAR_ADD = 308,
    UNAR_SUBTRACT = 309,
    UNAR_AND = 310,
    STARR = 311,
    PLUSS = 312,
    MINUSS = 313,
    TILDO = 314,
    NOTT = 315,
    FORWAD_SLASH = 316,
    PERCENTLE = 317,
    LEF_SHIFT = 318,
    RIGH_SHIFT = 319,
    LEF_ANGULAR_BRACE = 320,
    RIGH_ANGULAR_BRACE = 321,
    LESS_EQUALL = 322,
    GREATER_EQUALL = 323,
    DOUBLE_EQUALL = 324,
    NOT_EQUALL = 325,
    CARROT = 326,
    ONE_OR = 327,
    TWO_AND = 328,
    TWO_OR = 329,
    Q_MARK = 330,
    COLOND = 331,
    TRIPLE_DOTS = 332,
    EQUALL = 333,
    STAR_EQUALL = 334,
    SLASH_EQUALL = 335,
    PERCENTILE_EQUALL = 336,
    PLUS_EQUALL = 337,
    MINUS_EQUALL = 338,
    LEF_SHIFT_EQUALL = 339,
    RIGH_SHIFT_EQUALL = 340,
    AND_EQUALL = 341,
    HAT_EQUALL = 342,
    OR_EQUALL = 343,
    HASHED = 344,
    COMMAS = 345,
    SEMI_COLOND = 346
  };
#endif
/* Tokens.  */
#define INT_NUMBER 258
#define FLOAT_NUMBER 259
#define CHARACTER 260
#define IDENTIFIER 261
#define STRING_LITERAL 262
#define KEYWOD_AUTO 263
#define KEYWOD_BREAK 264
#define KEYWOD_CASE 265
#define KEYWOD_CHAR 266
#define KEYWOD_CONST 267
#define KEYWOD_CONTINUE 268
#define KEYWOD_DEFAULT 269
#define KEYWOD_DO 270
#define KEYWOD_DOUBLE 271
#define KEYWOD_ELSE 272
#define KEYWOD_ENUM 273
#define KEYWOD_EXTERN 274
#define KEYWOD_FLOAT 275
#define KEYWOD_FOR 276
#define KEYWOD_GOTO 277
#define KEYWOD_IF 278
#define KEYWOD_INLINE 279
#define KEYWOD_INT 280
#define KEYWOD_LONG 281
#define KEYWOD_REGISTER 282
#define KEYWOD_RESTRICT 283
#define KEYWOD_RETURN 284
#define KEYWOD_SHORT 285
#define KEYWOD_SIGNED 286
#define KEYWOD_SIZEOF 287
#define KEYWOD_STATIC 288
#define KEYWOD_STRUCT 289
#define KEYWOD_SWITCH 290
#define KEYWOD_TYPEDEF 291
#define KEYWOD_UNION 292
#define KEYWOD_UNSIGNED 293
#define KEYWOD_VOID 294
#define KEYWOD_VOLATILE 295
#define KEYWOD_WHILE 296
#define KEYWOD_BOOL 297
#define KEYWOD_COMPLEX 298
#define KEYWOD_IMAGINARY 299
#define LEF_SQUARE_BRACKET 300
#define RIGH_SQUARE_BRACKET 301
#define LEF_PARANTHESIS 302
#define RIGH_PARANTHESIS 303
#define LEF_CURLY_BRACKET 304
#define RIGH_CURLY_BRACKET 305
#define DOT 306
#define RIGH_ARROW 307
#define UNAR_ADD 308
#define UNAR_SUBTRACT 309
#define UNAR_AND 310
#define STARR 311
#define PLUSS 312
#define MINUSS 313
#define TILDO 314
#define NOTT 315
#define FORWAD_SLASH 316
#define PERCENTLE 317
#define LEF_SHIFT 318
#define RIGH_SHIFT 319
#define LEF_ANGULAR_BRACE 320
#define RIGH_ANGULAR_BRACE 321
#define LESS_EQUALL 322
#define GREATER_EQUALL 323
#define DOUBLE_EQUALL 324
#define NOT_EQUALL 325
#define CARROT 326
#define ONE_OR 327
#define TWO_AND 328
#define TWO_OR 329
#define Q_MARK 330
#define COLOND 331
#define TRIPLE_DOTS 332
#define EQUALL 333
#define STAR_EQUALL 334
#define SLASH_EQUALL 335
#define PERCENTILE_EQUALL 336
#define PLUS_EQUALL 337
#define MINUS_EQUALL 338
#define LEF_SHIFT_EQUALL 339
#define RIGH_SHIFT_EQUALL 340
#define AND_EQUALL 341
#define HAT_EQUALL 342
#define OR_EQUALL 343
#define HASHED 344
#define COMMAS 345
#define SEMI_COLOND 346

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE YYSTYPE;
union YYSTYPE
{
#line 9 "ass3_14CS10037.y" /* yacc.c:1909  */

	int intval;
	float floatval;
	char* charval;

#line 242 "y.tab.h" /* yacc.c:1909  */
};
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
