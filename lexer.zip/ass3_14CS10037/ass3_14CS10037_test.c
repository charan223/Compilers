/* **This is a test file

   for checking the lexical analyzer**
*/


#include <stdio.h>


int main(){ // main //

	// list of keyword
	auto 	enum 	restrict 	unsigned
	break 	extern 	return 		void
	case 	float 	short 		volatile
	char 	for 	signed 		while
	const 	goto 	sizeof 		_Bool
	continue if 	static 		_Complex
	default inline 	struct 		_Imaginary
	do 	    int 	switch
	double 	long 	typedef
	else 	register union

	//check for identifier
	int _i9d1 = 9;
	float floaT_1id = 784.34;

	//checks for constant
	int i = 15413;
	float f11 = 245.143;
	float f21 = .8976;
	float f31 = 356.
	float f41 = 24.3e-13;
	float f51 = .525E34;
	float f61 = 53e-7;
	//character constant
	'swer\srr'
	'sri\'luu'
	//string literals
	""
	"456ghf\\"
	"sjks\a568w"

	//puctuator checks
	int t = 6+5-3<< 4.3%1>>15/4;
	float z = (x==t)?6:22.4
	y += 54E3;
	p[2] *= (x++)*(t->z)...&qw^~q;
	if(!a || c && b== e != d >= g <= f > i < h)  j^=k|=l
	func(r,q,p);
	return 0;
}

















