#include "y.tab.h"
#include <stdio.h>
extern int yylex();
extern char* yytext;
extern FILE* yyin;


int main(){
	int y;
	yyin=fopen("ass3_14CS10037_test.c","r");
	while(y = yylex()){
		if( y <= KEYWOD_IMAGINARY && y >= KEYWOD_AUTO){
			printf("<KEYWORD, %d, %s>\n", y, yytext);
		}
		if(y == IDENTIFIER){
			printf("<ID, %d, %s>\n", y, yytext);
		}
		if(y == CHARACTER){
			printf("<CHARACTER CONSTANT, %d, %s>\n", y, yytext);
		}
		if(y == STRING_LITERAL){
			printf("<STRING LITERAL, %d, %s>\n", y, yytext);
		}
		if(y == FLOAT_NUMBER){
			printf("<FLOAT CONSTANT, %d, %s>\n", y, yytext);
		}
		if(y == INT_NUMBER){
			printf("<INTEGER CONSTANT, %d, %s>\n", y, yytext);
		}
		if(y >= LEF_SQUARE_BRACKET && y <= SEMI_COLOND){
			printf("<PUNCTUATOR, %d, %s>\n", y, yytext);
		}

	}
	return 0;
}
