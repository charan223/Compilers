
#include "y.tab.h"
int main(){
  yydebug = 1;
  int z = yyparse();
  return 0;
}
